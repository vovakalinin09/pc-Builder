<?php
file_put_contents('/tmp/cart_debug.log', print_r($_POST, true) . PHP_EOL, FILE_APPEND);
class CartStorage {
    private const CART_KEY = 'SHOPPING_CART';
    
    public function __construct() {
        if (session_status() === PHP_SESSION_NONE) {
            session_start();
        }
    }

    public function getCart(): array {
        return $_SESSION[self::CART_KEY] ?? [];
    }

    public function addItem(int $productId, int $quantity = 1): void {
        $cart = $this->getCart();
        $cart[$productId] = ($cart[$productId] ?? 0) + $quantity;
        $_SESSION[self::CART_KEY] = $cart;
    }

    public function updateQuantity(int $productId, int $quantity): void {
        if ($quantity <= 0) {
            $this->removeItem($productId);
            return;
        }
        $cart = $this->getCart();
        $cart[$productId] = $quantity;
        $_SESSION[self::CART_KEY] = $cart;
    }

    public function removeItem(int $productId): void {
        $cart = $this->getCart();
        unset($cart[$productId]);
        $_SESSION[self::CART_KEY] = $cart;
    }

    public function clear(): void {
        $_SESSION[self::CART_KEY] = [];
    }

    public function getTotalQuantity(): int {
        return array_sum($this->getCart());
    }
}