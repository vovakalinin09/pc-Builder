<?php
require_once __DIR__ . '/internal/bootstrap.php';
require_once __DIR__ . '/internal/db.php';
$pingOk = false;
$error = '';
try {
    pingDbConnection();
    $pingOk = true;
} catch (Exception $e) {
    $error = $e->getMessage();
}
?>
<!DOCTYPE html>
<html>
<head><title>PC Builder — Главная</title></head>
<body style="font-family: sans-serif; text-align: center; margin-top: 50px;">
    <h1>🖥️ PC Builder</h1>
    <p>Интернет-магазин компьютерных комплектующих и готовых сборок</p>
    <p>Статус БД: <?= $pingOk ? '✅ Подключено' : '❌ Ошибка: ' . htmlspecialchars($error) ?></p>
    <p><a href="/pages/shop/index.php">Перейти в магазин</a> | <a href="/pages/admin/dashboard.php">Админ-панель</a></p>
</body>
</html>