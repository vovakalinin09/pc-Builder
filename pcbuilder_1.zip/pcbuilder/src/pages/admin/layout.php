<?php
function renderAdminLayout(string $pageTitle, callable $contentCallback, int $activeMenu = 1): void {
?>
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin | <?= htmlspecialchars($pageTitle) ?></title>
    <link rel="stylesheet" href="/static/css/admin.css">
</head>
<body>
    <div class="admin-wrapper">
        <aside class="admin-sidebar">
            <h2>PC Builder Admin</h2>
            <nav>
                <ul>
                    <li><a href="/pages/admin/dashboard.php" class="<?= $activeMenu==1?'active':'' ?>">📊 Дашборд</a></li>
                    <li><a href="/pages/admin/categories/list.php" class="<?= $activeMenu==2?'active':'' ?>">📂 Категории</a></li>
                    <li><a href="/pages/admin/products/list.php" class="<?= $activeMenu==3?'active':'' ?>">🛒 Товары</a></li>
                    <li><a href="/pages/admin/orders/list.php" class="<?= $activeMenu==4?'active':'' ?>">📦 Заказы</a></li>
                </ul>
            </nav>
        </aside>
        <main class="admin-content">
            <header class="admin-header">
                <h1><?= htmlspecialchars($pageTitle) ?></h1>
            </header>
            <div class="admin-body">
                <?php $contentCallback(); ?>
            </div>
        </main>
    </div>
</body>
</html>
<?php } ?>