<?php
require_once __DIR__ . '/../../../internal/bootstrap.php';
require_once __DIR__ . '/../../../internal/deps.php';

$orderRepo = getOrderRepository();

// Обработка изменения статуса
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update_status'])) {
    $orderId = (int)$_POST['order_id'];
    $status = $_POST['status'];
    $orderRepo->updateStatus($orderId, $status);
    header('Location: list.php');
    exit;
}

// Обработка удаления заказа (если реализовано)
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['delete_order'])) {
    $orderId = (int)$_POST['order_id'];
    $orderRepo->deleteOrder($orderId);
    header('Location: list.php');
    exit;
}

$orders = $orderRepo->getAllOrders();

$statusLabels = [
    'new' => 'Новый',
    'processing' => 'В обработке',
    'completed' => 'Выполнен',
    'cancelled' => 'Отменён'
];

$content = function() use ($orders, $statusLabels) { ?>
    <h2>Заказы</h2>
    <?php if (empty($orders)): ?>
        <p>Заказов пока нет.</p>
    <?php else: ?>
        <table class="admin-table orders-table">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Клиент</th>
                    <th>Контакты</th>
                    <th>Товары</th>
                    <th>Сумма</th>
                    <th>Дата</th>
                    <th>Статус</th>
                    <th>Действие</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($orders as $order): ?>
                <tr>
                    <td>#<?= $order['id'] ?></td>
                    <td><?= htmlspecialchars($order['name']) ?></td>
                    <td><?= htmlspecialchars($order['phone']) ?><br><?= htmlspecialchars($order['email']) ?></td>
                    <td><?= htmlspecialchars($order['items']) ?></td>
                    <td><?= number_format($order['total'], 0, '.', ' ') ?> ₽</td>
                    <td><?= $order['date'] ?></td>
                    <td class="status-actions">
                        <form method="POST" style="display:flex; gap:5px;">
                            <input type="hidden" name="order_id" value="<?= $order['id'] ?>">
                            <select name="status" class="status-select" data-id="<?= $order['id'] ?>">
                                <?php foreach ($statusLabels as $val => $label): ?>
                                    <option value="<?= $val ?>" <?= $order['status'] === $val ? 'selected' : '' ?>><?= $label ?></option>
                                <?php endforeach; ?>
                            </select>
                            <button type="submit" name="update_status" class="btn-small">Обновить</button>
                        </form>
                    </td>
                    <td>
                        <form method="POST" onsubmit="return confirm('Удалить заказ?');">
                            <input type="hidden" name="order_id" value="<?= $order['id'] ?>">
                            <button type="submit" name="delete_order" class="btn-danger">🗑️</button>
                        </form>
                    </td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    <?php endif; ?>
<?php };
require_once '../layout.php';
renderAdminLayout('Заказы', $content, 4);