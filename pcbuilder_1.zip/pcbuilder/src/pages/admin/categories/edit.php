<?php
require_once __DIR__ . '/../../../internal/bootstrap.php';
require_once __DIR__ . '/../../../internal/deps.php';
$repo = getCategoryRepository();
$id = (int)($_GET['id'] ?? 0);
$category = $repo->getById($id);
if (!$category) { header('Location: list.php'); exit; }
$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = trim($_POST['name'] ?? '');
    $slug = trim($_POST['slug'] ?? '');
    if ($name && $slug) {
        if ($repo->update($id, $name, $slug)) {
            header('Location: list.php');
            exit;
        } else $error = 'Ошибка обновления';
    } else $error = 'Заполните все поля';
}
$content = function() use ($category, $error) { ?>
    <h2>Редактировать категорию</h2>
    <?php if ($error): ?><p style="color:red;"><?= $error ?></p><?php endif; ?>
    <form method="POST">
        <label>Название: <input type="text" name="name" value="<?= htmlspecialchars($category->name) ?>" required></label><br>
        <label>Slug: <input type="text" name="slug" value="<?= htmlspecialchars($category->slug) ?>" required></label><br>
        <button type="submit">Обновить</button>
    </form>
<?php };
require_once '../layout.php';
renderAdminLayout('Редактировать категорию', $content, 2);
?>