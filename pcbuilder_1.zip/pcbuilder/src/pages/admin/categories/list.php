<?php
require_once __DIR__ . '/../../../internal/bootstrap.php';
require_once __DIR__ . '/../../../internal/deps.php';

$repo = getCategoryRepository();
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['delete'])) {
    $id = (int)$_POST['id'];
    $repo->delete($id);
    header('Location: list.php');
    exit;
}
$categories = $repo->getAll();
$content = function() use ($categories) { ?>
    <h2>Категории</h2>
    <a href="add.php" class="btn-add">➕ Добавить категорию</a>
    <table class="admin-table">
        <thead><tr><th>ID</th><th>Название</th><th>Slug</th><th>Действия</th></tr></thead>
        <tbody>
        <?php foreach ($categories as $cat): ?>
        <tr>
            <td><?= $cat->id ?></td>
            <td><?= htmlspecialchars($cat->name) ?></td>
            <td><?= htmlspecialchars($cat->slug) ?></td>
            <td>
                <a href="edit.php?id=<?= $cat->id ?>">✏️</a>
                <form method="POST" style="display:inline;" onsubmit="return confirm('Удалить?')">
                    <input type="hidden" name="id" value="<?= $cat->id ?>">
                    <button type="submit" name="delete" class="btn-link">🗑️</button>
                </form>
            </td>
        </tr>
        <?php endforeach; ?>
        </tbody>
    </td>
<?php };
require_once '../layout.php';
renderAdminLayout('Категории', $content, 2);