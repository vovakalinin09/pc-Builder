<?php
require_once __DIR__ . '/../../../internal/bootstrap.php';
require_once __DIR__ . '/../../../internal/deps.php';
$repo = getCategoryRepository();
$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = trim($_POST['name'] ?? '');
    $slug = trim($_POST['slug'] ?? '');
    if ($name && $slug) {
        if ($repo->add($name, $slug)) {
            header('Location: list.php');
            exit;
        } else $error = 'Ошибка добавления';
    } else $error = 'Заполните все поля';
}
$content = function() use ($error) { ?>
    <h2>Добавить категорию</h2>
    <?php if ($error): ?><p style="color:red;"><?= $error ?></p><?php endif; ?>
    <form method="POST">
        <label>Название: <input type="text" name="name" required></label><br>
        <label>Slug: <input type="text" name="slug" required></label><br>
        <button type="submit">Сохранить</button>
    </form>
<?php };
require_once '../layout.php';
renderAdminLayout('Добавить категорию', $content, 2);
?>